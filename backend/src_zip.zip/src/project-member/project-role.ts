export enum ProjectRole {
  OWNER = 'OWNER',
  MAINTAINER = 'MAINTAINER',
  DEVELOPER = 'DEVELOPER',
  VIEWER = 'VIEWER',
}